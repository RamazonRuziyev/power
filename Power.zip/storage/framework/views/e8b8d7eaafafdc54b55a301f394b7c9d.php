<?php $__env->startSection('title','Petition accept'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 p-3">
                <div class="card">
                    <div class="card-header d-flex align-items-center justify-content-around">
                        <h3 class="card-title">Ariza qabul qilish </h3>
                        <h4 class="btn  btn-success" ><?php echo e($count); ?></h4>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table  class="table table-bordered">
                            <thead>
                            <tr>
                                <th style="width: 10px">#</th>
                                <th>FIO</th>
                                <th>MFY</th>
                                <th>Qishloqg'i</th>
                                <th>Telefon</th>
                                <th>tavsifi</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $petitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$petition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(($petitions->currentPage() -1) * $petitions->perPage() + ($loop->index +1)); ?></td>
                                    <td><?php echo e($petition->fio); ?></td>
                                    <td><?php echo e($petition->mfy); ?></td>
                                    <td><?php echo e($petition->village); ?></td>
                                    <td><?php echo e($petition->phone); ?></td>
                                    <td><?php echo e($petition->description); ?></td>
                                    <td>
                                        <?php if($petition->status == 1): ?>
                                            <span class="btn btn-success">Qabul qiling</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <br>
                        <div style="margin: 20px;"> <?php echo e($petitions->links()); ?></div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\Power\resources\views/admin/petition/petition_accept.blade.php ENDPATH**/ ?>