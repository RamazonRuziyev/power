<?php $__env->startSection('title','petition'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <!-- left column -->
        <div class="col-md-12 p-3" >
            <!-- jquery validation -->
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Xbarlarni tahrirlash</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <form action="<?php echo e(route('petition.update',$petition)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Fio</label>
                            <input type="text" value="<?php echo e($petition->fio); ?>" name="name" class="form-control" id="exampleInputEmail1" placeholder="rayon name">
                        </div>
                        <div class="form-group">
                            <label for="">Mfy</label> <br>
                            <select name="mfy" id="" class="form-control">
                            <?php if($petition->mfy): ?>
                                    <option selected disabled value="<?php echo e($petition->id); ?>"><?php echo e($petition->mfy); ?></option>
                                    <option>Churkalon Mfy</option>
                                    <option>Yangijon Mfy</option>
                                    <option>Bekabad Mfy</option>
                            <?php else: ?>
                                    <option>Churkalon Mfy</option>
                                    <option>Yangijon Mfy</option>
                                    <option>Bekabad Mfy</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Qishlog'i</label>
                            <input type="text"  value="<?php echo e($petition->village); ?>"  name="village" class="form-control" id="exampleInputEmail1" placeholder="Qishlog'i">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Telefon</label>
                            <input type="text"  value="<?php echo e($petition->phone); ?>" name="phone" class="form-control" id="exampleInputEmail1" placeholder="Telefon">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">tavsifi</label>
                            <textarea class="form-control"  name="desc" id="" cols="30" rows="4" placeholder="tavsifi"><?php echo e($petition->description); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Masul Xodim</label>
                            <input type="text"  value="<?php echo e($petition->employee); ?>" name="employee" class="form-control" id="exampleInputEmail1" placeholder="Xodim">
                        </div>

                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">tahrirlash</button>
                    </div>
                </form>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('profiles.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\Power\resources\views/profiles/petition/edit.blade.php ENDPATH**/ ?>