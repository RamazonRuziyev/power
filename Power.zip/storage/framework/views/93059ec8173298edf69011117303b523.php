<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('superAdmin')); ?>" class="brand-link">
        <img src="<?php echo e(asset('profile/dist/img/AdminLTELogo.png')); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">Profil</span>
    </a>
    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <a href="<?php echo e(route('setting.super')); ?>">
            <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                <div class="image">
                    <?php if(\Illuminate\Support\Facades\Auth::user()->avatar): ?>
                        <img src="<?php echo e(Storage::url('public/avatar/'.\Illuminate\Support\Facades\Auth::user()->avatar)); ?>" class="img-circle elevation-2" alt="User Image">
                    <?php else: ?>
                        <img src="<?php echo e(asset('profile/dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
                    <?php endif; ?>
                </div>
                <div class="info">
                    <a href="<?php echo e(route('setting.super')); ?>" class="d-block">
                        <?php echo e(Auth::user()->name); ?>

                    </a>
                </div>
            </div>
        </a>
        <!-- SidebarSearch Form -->
        <div class="form-inline">
            <div class="input-group" data-widget="sidebar-search">
                <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
                <div class="input-group-append">
                    <button class="btn btn-sidebar">
                        <i class="fas fa-search fa-fw"></i>
                    </button>
                </div>
            </div>
        </div>
        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <!-- Add icons to the links using the .nav-icon class
                     with font-awesome or any other icon font library -->
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-book"></i>
                        <p>
                            Users
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview <?php echo e((request()->is('Administrator/user/view') || request()->routeIs('user.edit') )? 'd-block' : ''); ?>">
                        <li class="nav-item">
                            <a style="color: <?php echo e((request()->is('Administrator/user/view') || request()->routeIs('user.edit') )? 'blue' : ''); ?>" href="<?php echo e(route('user.view')); ?>" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>User all</p>
                            </a>
                        </li>






                    </ul>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-book"></i>
                        <p>
                            Xodim
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview <?php echo e((request()->is('Administrator/xodim') || request()->is('Administrator/xodin/all/adm') || request()->routeIs('user.show'))? 'd-block' : ''); ?>">
                        <li class="nav-item">
                            <a style="color: <?php echo e(request()->is('Administrator/xodim') ? 'blue' : ''); ?>" href="<?php echo e(route('user.all')); ?>" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>xodim</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a style="color: <?php echo e((request()->is('Administrator/xodin/all/adm') || request()->routeIs('user.show') )? 'blue' : ''); ?>" href="<?php echo e(route('user.adm')); ?>" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Xomdim all</p>
                            </a>
                        </li>
                    </ul>
                </li>


                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-chart-pie"></i>
                        <p>
                            Role
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview <?php echo e((request()->is('Administrator/role') || request()->is('Administrator/role/yaratish'))?'d-block' : ''); ?>">
                        <li class="nav-item">
                            <a style="color: <?php echo e(request()->is('Administrator/role/yaratish') ? 'blue' : ''); ?>" href="<?php echo e(route('role.create')); ?>" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Role yaratish</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a style="color: <?php echo e(request()->is('Administrator/role') ? 'blue' : ''); ?>" href="<?php echo e(route('role')); ?>" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Role</p>
                            </a>
                        </li>

                    </ul>
                </li>

            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\OSPanel\domains\Power\resources\views/SuperAdmin/partial/sidebar.blade.php ENDPATH**/ ?>