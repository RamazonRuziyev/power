<?php $__env->startSection('title','xabar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 p-3">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Ariza</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>FIO</th>
                                <th>MFY</th>
                                <th>Qishloqg'i</th>
                                <th>Telefon</th>

                                <th>tavsifi</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e($petition->fio); ?></td>
                                    <td><?php echo e($petition->mfy); ?></td>
                                    <td><?php echo e($petition->village); ?></td>
                                    <td><?php echo e($petition->phone); ?></td>

                                    <td><?php echo e($petition->description); ?></td>
                                    <td class="d-flex">
                                        <a class="btn btn-primary"  href="<?php echo e(route('dashboard.notification.accept',$petition)); ?>">Accept</a>&nbsp;&nbsp;
                                        <a class="btn btn-danger"  href="<?php echo e(route('dashboard.notification.cancel',$petition)); ?>">Cancel</a>
                                    </td>
                                </tr
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\Power\resources\views/admin/petition/show.blade.php ENDPATH**/ ?>