<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\Power\resources\views/admin/index.blade.php ENDPATH**/ ?>