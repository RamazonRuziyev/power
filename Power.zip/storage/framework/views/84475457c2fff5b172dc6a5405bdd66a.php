<?php $__env->startSection('title','Administrator'); ?>
<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('SuperAdmin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\Power\resources\views/SuperAdmin/index.blade.php ENDPATH**/ ?>