<?php $__env->startSection('title','Xodim'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 p-3">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Xodim Kurish</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>№</th>
                                <th>Name</th>
                                <th>Ariza umimiy necha</th>
                                <th>Qabul qilinganlar soni</th>
                                <th>Qabul qilinmaganlar soni</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(($employees->currentPage() -1 ) * $employees->perPage() + ($loop->index +1)); ?></td>
                                    <td><?php echo e($employee->name); ?></td>
                                <?php
                                    $total = $petitions->where('employee', $employee->id)->count();
                                    $accepted = $petitions->where('employee', $employee->id)->where('status', 1)->count();
                                    $canceled = $petitions->where('employee', $employee->id)->where('status', 2)->count();
                                ?>
                                    <td><?php echo e($total); ?></td>
                                    <td><?php echo e($accepted); ?></td>
                                    <td><?php echo e($canceled); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <br>
                        <div style="margin: 20px;"> <?php echo e($employees->links()); ?></div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('SuperAdmin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\Power\resources\views/SuperAdmin/xodim/index.blade.php ENDPATH**/ ?>