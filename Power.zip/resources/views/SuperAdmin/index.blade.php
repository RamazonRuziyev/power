@extends('SuperAdmin.layout.master')
@section('title','Administrator')
@section('content')

@endsection
