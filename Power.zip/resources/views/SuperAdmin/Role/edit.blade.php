@extends('SuperAdmin.layout.master')
@section('title','Role tahrirlash')
@section('content')

@endsection
