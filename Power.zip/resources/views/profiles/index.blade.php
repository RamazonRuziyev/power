@extends('profiles.layout.master')
@section('title','Ariza')
@section('content')

@endsection
