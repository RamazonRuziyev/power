@extends('admin.layout.master')
@section('title','Dashboard')
@section('content')

@endsection
